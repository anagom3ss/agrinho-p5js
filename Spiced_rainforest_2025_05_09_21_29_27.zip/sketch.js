 let tractorX, tractorY;
let beanX, beanY;
let beanCollected = false;

function setup() {
  createCanvas(400, 400);
  tractorX = width / 2;
  tractorY = height - 50;
  beanX = random(50, width - 50);
  beanY = random(50, height - 150);
}

function draw() {
  background(200);

  // Desenhando o emoji do trator
  textSize(50);
  textAlign(CENTER, CENTER);
  text("🚜", tractorX, tractorY);

  // Desenhando o emoji do feijão
  if (!beanCollected) {
    textSize(50);
    text("🫘", beanX, beanY);
  }

  // Lógica para o trator se mover em direção ao feijão
  if (beanCollected === false) {
    if (tractorX < beanX) {
      tractorX += 1;
    } else if (tractorX > beanX) {
      tractorX -= 1;
    }
    if (tractorY < beanY) {
      tractorY += 1;
    } else if (tractorY > beanY) {
      tractorY -= 1;
    }
  }

  // Verificar se o trator "colheu" o feijão
  let d = dist(tractorX, tractorY, beanX, beanY);
  if (d < 30) {
    beanCollected = true;
    beanX = random(50, width - 50);
    beanY = random(50, height - 150);
  }

  // Se o feijão for colhido, pode aparecer uma mensagem
  if (beanCollected) {
    textSize(32);
    text("Feijão colhido!", width / 2, height - 100);
  }
}
